package homeworkDay5;

public class AbcShopCampaignManager extends BaseCampaignManager{

	@Override
	public void newCampaign(Product product, double discountCampaign) {
		// TODO Auto-generated method stub
		super.newCampaign(product, discountCampaign);
	}

	@Override
	public void updateCampaign(Product product, double discountCampaign) {
		// TODO Auto-generated method stub
		super.updateCampaign(product, discountCampaign);
	}

	@Override
	public void deleteCampaign(Product product) {
		// TODO Auto-generated method stub
		super.deleteCampaign(product);
	}
	
}
