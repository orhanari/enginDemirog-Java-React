package homeworkDay5;

public abstract class BaseCustomerManager implements CustomerService{

	@Override
	public void registerCustomer(Customer customer) {
		System.out.println("Kay�t ba�ar�l�: " + customer.getFirstName());
	}

	@Override
	public void updateCustomer(Customer customer) {
		System.out.println("Kay�t g�ncelleme ba�ar�l�: " + customer.getFirstName());
	}

	@Override
	public void deleteCustomer(Customer customer) {
		System.out.println("Kay�t silme ba�ar�l�: " + customer.getFirstName());
	}
	
}
