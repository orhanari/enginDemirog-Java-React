package homeworkDay5;

public interface CustomerCheckService {
	boolean checkIfRealPerson(Customer customer);
}
