package homeworkDay5;

public interface CustomerService {
	void registerCustomer(Customer customer);
	void updateCustomer(Customer customer);
	void deleteCustomer(Customer customer);
}
