package homeworkDay4;

public class NeroCustomerManager extends BaseCustomerManager{
	
}
