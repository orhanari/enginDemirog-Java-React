package homeworkDay4;

public interface CustomerCheckService {
	boolean checkIfRealPerson(Customer customer);
}
