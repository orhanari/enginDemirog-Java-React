package homeworkDay4;

public interface CustomerService {
	void save(Customer customer);
}
