package eCommerce;

import eCommerce.business.abstracts.MemberService;
import eCommerce.business.concretes.MemberManager;
import eCommerce.dataAccess.concretes.GoogleMemberDao;
import eCommerce.dataAccess.concretes.StandartMemberDao;
import eCommerce.entities.concretes.Member;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MemberService memberService = new MemberManager(new StandartMemberDao());
		
		Member member = new Member(0, "Orhan", "ARI", "orhanari55@gmail.com", "123456");
		memberService.registerMember(member);
		
		System.out.println("");
		Member member2 = new Member(1, "Orhan", "ARI", "orhanari55@gmail.com", "123456");
		memberService.registerMember(member2);
		
		System.out.println("");
		Member member3 = new Member(2, "Engin", "Demiro�", "engin@kodlama.io", "123456");
		memberService.registerMember(member3);
		
		System.out.println("");
		Member member4 = new Member(3, "Engin", "Demiro�", "engin@", "123456");
		memberService.registerMember(member4);
		
		// DO�RULAMALAR TAMAMLANDI. AKT�VASYON KONTROL� YAPILIYOR:
		
		System.out.println("");
		memberService.loginMember("orhanari55@gmail.com","123456");
		// AKT�VASYONSUZ G�R�� DENEMES�:
		// ��kt�: Hesap aktivasyonu tamamlanmam��!: orhanari55@gmail.com
		
		System.out.println("");
		memberService.activateMember("1099");
		// GE�ERS�Z AKT�VASYON KODU:
		// ��kt�: Ge�ersiz aktivasyon kodu!
		
		System.out.println("");
		memberService.activateMember("1111");
		// DO�RU AKT�VASYON NUMARASI
		// Aktivasyon ba�ar�l�: 1111
		
		
		System.out.println("");
		memberService.loginMember("orhanari55@gmail.com","123456");
		// AKT�VASYON SONRASI G�R�� DENEMES�:
		// Giri� ba�ar�l�: orhanari55@gmail.com
		
		System.out.println("");
		
		
		// GOOGLE MEMBER DAO
		
		MemberService memberService2 = new MemberManager(new GoogleMemberDao());
		
		Member googleMember = new Member(4, "Orhan", "ARI", "orhanari@outlook.com", "123456");
		memberService2.registerMember(googleMember);
		
		System.out.println("");
		memberService2.loginMember("orhanari@outlook.com","123456");
		// GOOGLE �LE KAYIT OLUNMASINDAN �T�R�, AKT�VASYON OTOMAT�K TAMAMLANMI�TIR:
		// ��kt�: Giri� ba�ar�l�: orhanari@outlook.com
		
		
	}

}
