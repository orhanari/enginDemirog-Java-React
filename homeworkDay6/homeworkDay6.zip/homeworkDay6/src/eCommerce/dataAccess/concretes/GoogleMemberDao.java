package eCommerce.dataAccess.concretes;

import eCommerce.dataAccess.abstracts.MemberDao;
import eCommerce.entities.concretes.Member;

public class GoogleMemberDao implements MemberDao{

	@Override
	public void registerMember(Member member) {
		System.out.println("Merhaba "+ member.getFirstName() + ".\n" + member.geteMail() + " mail adresiyle Google kay�t y�ntemi ile kay�t oldun ve hesab�n do�rudan aktifle�tirildi.");
		member.setActive(true);
	}
	
	@Override
	public void loginMember(String eMail, String pass) {
		System.out.println("Giri� ba�ar�l�: " + eMail);
	}
	
	@Override
	public void activateMember(String activationCode) {
		System.out.println("Aktivasyon ba�ar�l�.");
	}

}
