package eCommerce.dataAccess.concretes;

import java.util.List;

import eCommerce.dataAccess.abstracts.MemberDao;
import eCommerce.entities.concretes.Member;

public class StandartMemberDao implements MemberDao{

	@Override
	public void registerMember(Member member) {
		System.out.println("Merhaba "+ member.getFirstName() + ".\n" + member.geteMail() + " mail adresiyle standart kay�t y�ntemi ile kay�t oldun.\nL�tfen mail adresine g�nderilen do�rulama linki �zerinden hesab�n� aktifle�tir.\n(Kolayl�k olmas� i�in aktivasyon kodu buraya yaz�lm��t�r: " + member.getActivateCode() + ")");
	}
	
	@Override
	public void loginMember(String eMail, String pass) {
		System.out.println("Giri� ba�ar�l�: " + eMail);
	}
	
	@Override
	public void activateMember(String activationCode) {
		System.out.println("Aktivasyon ba�ar�l�.");
	}

}
