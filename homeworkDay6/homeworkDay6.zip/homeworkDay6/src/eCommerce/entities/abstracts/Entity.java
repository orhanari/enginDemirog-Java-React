package eCommerce.entities.abstracts;

public interface Entity {

}
